---
id: procedure.contract.create
category: contracts
name: Create or revise a procedure contract
governs: write_procedure
status: active
revised-by: Claude Fable 5, 2026-08-17 — removed the reference to a contract "parent", which no tool can express
---

## Description
How to author the instructions that govern this system — including this one.

## Instructions
1. Search for an overlapping contract first with `find_procedures`. Revise it rather than adding
   a near-duplicate. The write itself warns you when something looks similar; do not ignore it.
2. Decide its category — reuse an existing one where you can — and keep the scope narrow. One
   contract answers one question.
3. State what it `governs` — the tools or operations it applies to. Without this, a later agent
   cannot tell whether your contract is the relevant one, and the system's central rule collapses
   into guesswork.
4. Separate enforceable invariants from prose guidance: instructions are how to proceed,
   constraints are what must not happen.
5. Add an example whenever the wording could be read two ways.
6. Write it for a reader with no prior context. Assume nothing about what came earlier.
7. Call with `dryRun` first and read every named check it reports back.
8. Writing an existing id appends a revision — it never overwrites. Say why in the change note.

## Constraints
- Ids are permanent. There is no rename and no delete; the only retirement is
  `status: deprecated` or `status: archived`. Choose the id as carefully as a public API name.
- Never write a constraint you cannot state as a checkable condition; if it is advice, it is an
  instruction, not a constraint.
- Reuse an existing category unless the contract genuinely opens a new area.
