using DantesRoleplay.Operations;
using Microsoft.EntityFrameworkCore;

namespace DantesRoleplay.DataAccess;

/// <summary>
/// Records what the agent did.
///
/// The interesting part is <see cref="RecentlyReadProceduresAsync"/>. The audit log's whole point
/// is answering "was the operating manual actually followed?", and a self-reported list of
/// consulted procedures cannot answer that — an agent that skipped the manual can still claim it
/// didn't. But every get_procedure call is itself logged, so what was really read is already
/// recorded. Deriving the observed list from the log needs no session state, which matters
/// because the MCP host runs stateless.
/// </summary>
public sealed class OperationLog(DantesRoleplayDbContext db) : IOperationLog
{
    /// <summary>
    /// How far back a read counts as "consulted for this operation".
    ///
    /// Arbitrary, and deliberately generous: the cost of including a stale read is a slightly
    /// noisy audit row, while the cost of excluding a real one is a false accusation that the
    /// agent cited something it never opened. Err towards the former.
    /// </summary>
    private static readonly TimeSpan ReadWindow = TimeSpan.FromMinutes(30);

    private const string ReadTool = "get_procedure";

    private readonly DantesRoleplayDbContext _db = db;

    public async Task<Operation> RecordAsync(
        string tool,
        string summary,
        bool success,
        string intent = "",
        string subject = "",
        IEnumerable<string>? proceduresCited = null,
        string error = "",
        CancellationToken cancellationToken = default)
    {
        // Derive the observed list BEFORE writing this row, so a get_procedure call never counts
        // itself as one of its own prerequisites.
        var read = tool == ReadTool
            ? []
            : await RecentlyReadProceduresAsync(cancellationToken);

        var operation = new Operation
        {
            Id = Guid.NewGuid().ToString("n"),
            Timestamp = DateTime.UtcNow,
            Tool = tool,
            Subject = subject,
            Intent = intent,
            ProceduresCited = proceduresCited is null ? string.Empty : string.Join(",", proceduresCited),
            ProceduresRead = string.Join(",", read),
            Summary = summary,
            Success = success,
            Error = error
        };

        _db.Operations.Add(operation);
        await _db.SaveChangesAsync(cancellationToken);

        return operation;
    }

    public async Task<IReadOnlyList<string>> RecentlyReadProceduresAsync(
        CancellationToken cancellationToken = default)
    {
        var since = DateTime.UtcNow - ReadWindow;

        var subjects = await _db.Operations
            .AsNoTracking()
            .Where(o => o.Tool == ReadTool && o.Success && o.Timestamp >= since && o.Subject != "")
            .OrderByDescending(o => o.Timestamp)
            .Select(o => o.Subject)
            .Take(100)
            .ToListAsync(cancellationToken);

        return subjects.Distinct(StringComparer.Ordinal).OrderBy(s => s, StringComparer.Ordinal).ToList();
    }

    public async Task<IReadOnlyList<Operation>> RecentAsync(
        int limit = 20,
        bool failuresOnly = false,
        string? tool = null,
        string? subject = null,
        CancellationToken cancellationToken = default)
    {
        var query = _db.Operations.AsNoTracking();

        if (failuresOnly)
        {
            query = query.Where(o => !o.Success);
        }

        if (!string.IsNullOrWhiteSpace(tool))
        {
            query = query.Where(o => o.Tool == tool);
        }

        if (!string.IsNullOrWhiteSpace(subject))
        {
            query = query.Where(o => o.Subject == subject);
        }

        // Ordering on Timestamp is why it is a DateTime and not a DateTimeOffset: SQLite cannot
        // translate ORDER BY over DateTimeOffset at all.
        return await query
            .OrderByDescending(o => o.Timestamp)
            .Take(limit)
            .ToListAsync(cancellationToken);
    }
}
