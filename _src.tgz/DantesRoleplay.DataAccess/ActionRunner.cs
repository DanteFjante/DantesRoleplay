using System.Security.Cryptography;
using System.Text.Json;
using DantesRoleplay.Actions;
using DantesRoleplay.Effects;
using DantesRoleplay.Mechanics;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace DantesRoleplay.DataAccess;

/// <summary>
/// Composes the action pipeline and owns its transaction. The MCP layer delegates here; it does
/// not select mechanics, interpret projections or write the world itself.
/// </summary>
public sealed class ActionRunner(
    DantesRoleplayDbContext db,
    IMechanicStore mechanics,
    IProjectionResolver projections,
    IMechanicEngine engine,
    IEffectApplier applier,
    DantesRoleplay.Operations.IOperationLog log) : IActionRunner
{
    private const string Tool = "run_action";
    private readonly DantesRoleplayDbContext _db = db;
    private readonly IMechanicStore _mechanics = mechanics;
    private readonly IProjectionResolver _projections = projections;
    private readonly IMechanicEngine _engine = engine;
    private readonly IEffectApplier _applier = applier;
    private readonly DantesRoleplay.Operations.IOperationLog _log = log;

    public async Task<ActionRunResult> RunAsync(
        ActionRequest request,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var requestError = ValidateRequest(request);

        if (requestError is not null)
        {
            return await RecordFailureAsync(
                request,
                ActionRunResult.Failed(
                    requestError.Code,
                    requestError.Why,
                    requestError.Fix,
                    "Rejected run_action arguments."),
                null,
                null,
                null,
                CancellationToken.None);
        }

        IDbContextTransaction? transaction = null;
        MechanicSummary? selected = null;
        MechanicProjection? projection = null;
        long? seed = request.Seed;
        IReadOnlyList<MechanicSummary> candidates = [];

        try
        {
            transaction = await _db.Database.BeginTransactionAsync(cancellationToken);

            var found = await _mechanics.FindAsync(
                request.Intent,
                scope: request.Scope,
                includeInactive: true,
                limit: 50,
                cancellationToken: cancellationToken);

            candidates = found
                .Where(candidate => candidate.Status == MechanicStatus.Active)
                .ToList();

            if (candidates.Count == 0)
            {
                return await FailInTransactionAsync(
                    transaction,
                    request,
                    ActionRunResult.Failed(
                        "NO_ACTIVE_MECHANIC",
                        $"No active mechanic matched the intent '{request.Intent}'.",
                        "orient()",
                        $"No active mechanic matched '{request.Intent}'.",
                        found),
                    selected,
                    projection,
                    seed);
            }

            selected = candidates[0];
            var detail = await _mechanics.GetAsync(selected.Id, selected.Version, cancellationToken);

            if (detail is null || detail.Status != MechanicStatus.Active)
            {
                return await FailInTransactionAsync(
                    transaction,
                    request,
                    ActionRunResult.Failed(
                        "MECHANIC_UNAVAILABLE",
                        $"The selected mechanic '{selected.Id}' is no longer active.",
                        "orient()",
                        $"Selected mechanic '{selected.Id}' was unavailable.",
                        candidates),
                    selected,
                    projection,
                    seed);
            }

            seed ??= BitConverter.ToInt64(RandomNumberGenerator.GetBytes(sizeof(long)));

            MechanicRequirements requirements;

            try
            {
                requirements = MechanicRequirements.Parse(detail.Requirements);
            }
            catch (JsonException ex)
            {
                return await FailInTransactionAsync(
                    transaction,
                    request,
                    ActionRunResult.Failed(
                        "INVALID_REQUIREMENTS",
                        $"Mechanic '{selected.Id}' has invalid requirements JSON: {ex.Message}",
                        "get_procedure(id: \"procedure.mechanic.projection\")",
                        $"Mechanic '{selected.Id}' could not be projected.",
                        candidates),
                    selected,
                    projection,
                    seed);
            }

            var resolution = await _projections.ResolveAsync(
                requirements,
                request.RoleEntityIds,
                request.Input,
                seed.Value,
                cancellationToken);

            if (!resolution.Ok || resolution.Projection is null)
            {
                var problems = string.Join(
                    " ",
                    resolution.Problems.Select(problem =>
                        problem));

                return await FailInTransactionAsync(
                    transaction,
                    request,
                    ActionRunResult.Failed(
                        "PROJECTION_FAILED",
                        $"The mechanic projection was rejected. {problems}",
                        "get_procedure(id: \"procedure.mechanic.projection\")",
                        $"Projection failed for '{selected.Id}'.",
                        candidates) with { Mechanic = selected, Seed = seed },
                    selected,
                    projection,
                    seed);
            }

            projection = resolution.Projection;

            var run = await _engine.RunAsync(
                detail.Source,
                projection,
                ExecutionLimits.Default,
                cancellationToken);

            if (!run.Ok)
            {
                return await FailInTransactionAsync(
                    transaction,
                    request,
                    ActionRunResult.Failed(
                        string.IsNullOrWhiteSpace(run.LimitHit) ? "MECHANIC_FAILED" : "MECHANIC_LIMIT",
                        string.IsNullOrWhiteSpace(run.LimitHit)
                            ? run.Error
                            : $"{run.Error} Limit hit: {run.LimitHit}.",
                        "get_procedure(id: \"procedure.mechanic.run\")",
                        $"Mechanic '{selected.Id}' failed.",
                        candidates) with
                    {
                        Mechanic = selected,
                        Projection = projection,
                        Seed = seed,
                        Log = run.Log,
                        LimitHit = run.LimitHit,
                        ElapsedMilliseconds = run.ElapsedMilliseconds
                    },
                    selected,
                    projection,
                    seed);
            }

            var dryRun = await _applier.ApplyAsync(
                run.Output.Effects,
                dryRun: true,
                cancellationToken: cancellationToken);

            if (!dryRun.Valid)
            {
                return await FailInTransactionAsync(
                    transaction,
                    request,
                    ActionRunResult.Failed(
                        "INVALID_EFFECTS",
                        FormatProblems(dryRun.Problems),
                        "get_procedure(id: \"procedure.world.change\")",
                        $"Mechanic '{selected.Id}' proposed invalid effects.",
                        candidates) with
                    {
                        Mechanic = selected,
                        Projection = projection,
                        Output = run.Output,
                        Seed = seed,
                        Log = run.Log,
                        LimitHit = run.LimitHit,
                        ElapsedMilliseconds = run.ElapsedMilliseconds
                    },
                    selected,
                    projection,
                    seed);
            }

            // Apply the exact list that just passed the dry run. EffectApplier detects the ambient
            // transaction and leaves commit/rollback ownership with this runner.
            var applied = await _applier.ApplyAsync(
                run.Output.Effects,
                dryRun: false,
                cancellationToken: cancellationToken);

            if (!applied.Valid || !applied.Applied)
            {
                return await FailInTransactionAsync(
                    transaction,
                    request,
                    ActionRunResult.Failed(
                        "EFFECT_APPLICATION_FAILED",
                        FormatProblems(applied.Problems),
                        "get_procedure(id: \"procedure.world.change\")",
                        $"Mechanic '{selected.Id}' could not apply its effects.",
                        candidates) with
                    {
                        Mechanic = selected,
                        Projection = projection,
                        Output = run.Output,
                        Seed = seed,
                        Log = run.Log,
                        LimitHit = run.LimitHit,
                        ElapsedMilliseconds = run.ElapsedMilliseconds
                    },
                    selected,
                    projection,
                    seed);
            }

            var affected = AffectedEntities(run.Output.Effects);
            var subject = Subject(affected, selected.Id);
            var operation = await _log.RecordAsync(
                Tool,
                $"Ran {selected.Id} v{selected.Version}; applied {applied.Count} effect(s).",
                success: true,
                intent: request.Intent,
                subject: subject,
                proceduresCited: request.ProceduresUsed,
                consumesReadEvidence: true,
                cancellationToken: cancellationToken,
                mechanicId: selected.Id,
                mechanicVersion: selected.Version,
                seed: seed,
                projectionJson: Serialize(projection));

            await transaction.CommitAsync(cancellationToken);

            return new ActionRunResult
            {
                Ok = true,
                OperationId = operation.Id,
                Summary = $"Ran {selected.Id} v{selected.Version}; applied {applied.Count} effect(s).",
                Candidates = candidates,
                Mechanic = selected,
                Projection = projection,
                Output = run.Output,
                Seed = seed,
                AppliedCount = applied.Count,
                AffectedEntityIds = affected,
                Log = run.Log,
                LimitHit = run.LimitHit,
                ElapsedMilliseconds = run.ElapsedMilliseconds,
                NextSteps = ConfirmationSteps(affected)
            };
        }
        catch (OperationCanceledException)
        {
            if (transaction is null)
            {
                return await RecordFailureAsync(
                    request,
                    CancelledFailure(candidates, selected, projection, seed),
                    selected,
                    projection,
                    seed,
                    CancellationToken.None);
            }

            return await FailInTransactionAsync(
                transaction,
                request,
                ActionRunResult.Failed(
                    "CANCELLED",
                    "The action was cancelled before it completed.",
                    "history(tool: \"run_action\", failuresOnly: true)",
                    "Action cancelled.",
                    candidates) with
                {
                    Mechanic = selected,
                    Projection = projection,
                    Seed = seed
                },
                selected,
                projection,
                seed);
        }
        catch (Exception ex)
        {
            if (transaction is null)
            {
                return await RecordFailureAsync(
                    request,
                    ActionRunResult.Failed(
                        "UNHANDLED",
                        ex.Message,
                        "orient()",
                        "Unhandled run_action failure.",
                        candidates) with
                    {
                        Mechanic = selected,
                        Projection = projection,
                        Seed = seed
                    },
                    selected,
                    projection,
                    seed,
                    CancellationToken.None);
            }

            return await FailInTransactionAsync(
                transaction,
                request,
                ActionRunResult.Failed(
                    "UNHANDLED",
                    ex.Message,
                    "orient()",
                    "Unhandled run_action failure.",
                    candidates) with
                {
                    Mechanic = selected,
                    Projection = projection,
                    Seed = seed
                },
                selected,
                projection,
                seed);
        }
        finally
        {
            if (transaction is not null)
            {
                await transaction.DisposeAsync();
            }
        }
    }

    private async Task<ActionRunResult> FailInTransactionAsync(
        IDbContextTransaction transaction,
        ActionRequest request,
        ActionRunResult failure,
        MechanicSummary? mechanic,
        MechanicProjection? projection,
        long? seed)
    {
        await transaction.RollbackAsync(CancellationToken.None);
        _db.ChangeTracker.Clear();
        return await RecordFailureAsync(request, failure, mechanic, projection, seed, CancellationToken.None);
    }

    private async Task<ActionRunResult> RecordFailureAsync(
        ActionRequest request,
        ActionRunResult failure,
        MechanicSummary? mechanic,
        MechanicProjection? projection,
        long? seed,
        CancellationToken cancellationToken)
    {
        var operation = await _log.RecordAsync(
            Tool,
            failure.Summary,
            success: false,
            intent: request.Intent,
            subject: Subject(failure.AffectedEntityIds, mechanic?.Id ?? string.Empty),
            proceduresCited: request.ProceduresUsed,
            error: failure.Error?.Code ?? "UNHANDLED",
            consumesReadEvidence: true,
            cancellationToken: cancellationToken,
            mechanicId: mechanic?.Id ?? string.Empty,
            mechanicVersion: mechanic?.Version,
            seed: seed,
            projectionJson: projection is null ? string.Empty : Serialize(projection));

        return failure with { OperationId = operation.Id };
    }

    private static ActionRunResult CancelledFailure(
        IReadOnlyList<MechanicSummary> candidates,
        MechanicSummary? mechanic,
        MechanicProjection? projection,
        long? seed) =>
        ActionRunResult.Failed(
            "CANCELLED",
            "The action was cancelled before it completed.",
            "history(tool: \"run_action\", failuresOnly: true)",
            "Action cancelled.",
            candidates) with
        {
            Mechanic = mechanic,
            Projection = projection,
            Seed = seed
        };

    private static ActionRunError? ValidateRequest(ActionRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Intent))
        {
            return new ActionRunError(
                "INVALID_INTENT",
                "An action intent is required.",
                "run_action(intent: \"describe what the actor is trying to do\", roleEntityIds: {})");
        }

        try
        {
            using var document = JsonDocument.Parse(string.IsNullOrWhiteSpace(request.Input) ? "{}" : request.Input);
        }
        catch (JsonException ex)
        {
            return new ActionRunError(
                "INVALID_INPUT",
                $"The action input is not valid JSON: {ex.Message}",
                "run_action(intent: \"same intent\", roleEntityIds: {}, input: \"{}\")");
        }

        if (request.RoleEntityIds is null)
        {
            return new ActionRunError(
                "INVALID_ROLE_MAP",
                "The role-to-entity map cannot be null.",
                "run_action(intent: \"same intent\", roleEntityIds: {})");
        }

        if (request.RoleEntityIds.Any(pair =>
                string.IsNullOrWhiteSpace(pair.Key) || string.IsNullOrWhiteSpace(pair.Value)))
        {
            return new ActionRunError(
                "INVALID_ROLE_MAP",
                "Role names and entity ids must both be non-empty.",
                "run_action(intent: \"same intent\", roleEntityIds: { subject: \"entity-id\" })");
        }

        return null;
    }

    private static string FormatProblems(IReadOnlyList<EffectProblem> problems) =>
        problems.Count == 0
            ? "The effect applier rejected the action without a detailed problem."
            : $"{problems.Count} problem(s); nothing was applied. " +
              string.Join(" ", problems.Select(p => $"[{p.Index}] {p.Effect}: {p.Problem}"));

    private static IReadOnlyList<string> AffectedEntities(IReadOnlyList<Effect> effects) =>
        effects
            .SelectMany(effect => new[] { effect.EntityId, effect.ToEntityId })
            .Where(id => !string.IsNullOrWhiteSpace(id))
            .Select(id => id.Trim())
            .Distinct(StringComparer.Ordinal)
            .ToList();

    private static string Subject(IReadOnlyList<string> affected, string fallback)
    {
        var subject = affected.Count == 0 ? fallback : string.Join(",", affected);
        return subject.Length <= 200 ? subject : subject[..200];
    }

    private static IReadOnlyList<string> ConfirmationSteps(IReadOnlyList<string> affected) =>
        affected.Count == 0
            ? ["history(tool: \"run_action\") — review the recorded action result."]
            : [$"get_entities(ids: [{string.Join(", ", affected.Select(id => $"\"{id}\""))}]) — confirm the applied world state."];

    private static string Serialize(MechanicProjection projection) =>
        JsonSerializer.Serialize(projection);
}
