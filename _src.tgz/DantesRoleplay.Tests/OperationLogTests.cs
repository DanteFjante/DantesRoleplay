using DantesRoleplay.DataAccess;

namespace DantesRoleplay.Tests;

public sealed class OperationLogTests : IDisposable
{
    private readonly SqliteFixture _fixture = new();

    public void Dispose() => _fixture.Dispose();

    [Fact]
    public async Task Records_an_operation_and_returns_it_newest_first()
    {
        await using var db = _fixture.CreateContext();
        var log = new OperationLog(db);

        await log.RecordAsync("find_procedures", "listed 3", success: true);
        await log.RecordAsync(
            "write_procedure",
            "created procedure.system.modify v1",
            success: true,
            intent: "Add a modify procedure",
            subject: "procedure.system.modify",
            proceduresCited: ["procedure.contract.create"]);

        var recent = await log.RecentAsync();

        Assert.Equal(2, recent.Count);
        Assert.Equal("write_procedure", recent[0].Tool);
        Assert.Equal("procedure.contract.create", recent[0].ProceduresCited);
        Assert.Equal("procedure.system.modify", recent[0].Subject);
    }

    [Fact]
    public async Task Failures_can_be_isolated()
    {
        await using var db = _fixture.CreateContext();
        var log = new OperationLog(db);

        await log.RecordAsync("get_procedure", "ok", success: true);
        await log.RecordAsync("get_procedure", "not found", success: false, error: "UNKNOWN_PROCEDURE");

        var failures = await log.RecentAsync(failuresOnly: true);

        Assert.Single(failures);
        Assert.Equal("UNKNOWN_PROCEDURE", failures[0].Error);
    }

    [Fact]
    public async Task History_can_be_filtered_by_tool_and_subject()
    {
        await using var db = _fixture.CreateContext();
        var log = new OperationLog(db);

        await log.RecordAsync("get_procedure", "read a", success: true, subject: "procedure.a");
        await log.RecordAsync("get_procedure", "read b", success: true, subject: "procedure.b");
        await log.RecordAsync("write_procedure", "wrote a", success: true, subject: "procedure.a");

        Assert.Equal(2, (await log.RecentAsync(tool: "get_procedure")).Count);
        Assert.Equal(2, (await log.RecentAsync(subject: "procedure.a")).Count);
        Assert.Single(await log.RecentAsync(tool: "write_procedure", subject: "procedure.a"));
    }

    [Fact]
    public async Task Procedures_actually_read_are_observed_from_the_log_not_from_the_caller()
    {
        await using var db = _fixture.CreateContext();
        var log = new OperationLog(db);

        // The agent really opens one contract...
        await log.RecordAsync("get_procedure", "read", success: true, subject: "procedure.contract.create");

        // ...then claims it consulted a different one it never opened.
        var write = await log.RecordAsync(
            "write_procedure",
            "wrote",
            success: true,
            subject: "procedure.new",
            proceduresCited: ["procedure.system.modify"]);

        Assert.Equal("procedure.system.modify", write.ProceduresCited);
        Assert.Equal("procedure.contract.create", write.ProceduresRead);
    }

    [Fact]
    public async Task A_failed_read_does_not_count_as_having_consulted_a_procedure()
    {
        await using var db = _fixture.CreateContext();
        var log = new OperationLog(db);

        await log.RecordAsync("get_procedure", "not found", success: false, subject: "procedure.ghost");

        var write = await log.RecordAsync("write_procedure", "wrote", success: true, subject: "procedure.new");

        Assert.Equal(string.Empty, write.ProceduresRead);
    }

    [Fact]
    public async Task A_read_does_not_count_itself_as_its_own_prerequisite()
    {
        await using var db = _fixture.CreateContext();
        var log = new OperationLog(db);

        await log.RecordAsync("get_procedure", "read", success: true, subject: "procedure.a");
        var second = await log.RecordAsync("get_procedure", "read", success: true, subject: "procedure.b");

        Assert.Equal(string.Empty, second.ProceduresRead);
    }
}
